var request = require('request');
var cheerio = require('cheerio');
var URL = require('url-parse');
